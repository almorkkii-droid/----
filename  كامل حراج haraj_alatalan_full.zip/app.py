
from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3, os, secrets
from werkzeug.utils import secure_filename
from functools import wraps

app = Flask(__name__)
app.secret_key = secrets.token_hex(24)
DB = "haraj.db"
UPLOAD = "static/uploads"
os.makedirs(UPLOAD, exist_ok=True)

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ads(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL,
      price INTEGER NOT NULL, city TEXT NOT NULL, year INTEGER, damage TEXT,
      description TEXT, image TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    if c.execute("SELECT COUNT(*) FROM ads").fetchone()[0] == 0:
        c.execute("""INSERT INTO users(name,email,password) VALUES(?,?,?)""",
                  ("معلن تجريبي","demo@haraj.local","123456"))
        uid = c.lastrowid
        samples = [
            ("كامري 2018 مصدومة أمامي","سيارات مصدومة",15000,"الرياض",2018,"صدمة أمامية","سيارة بحالة موضحة بالصور.",None),
            ("لاندكروزر 2016 مصدوم","سيارات مصدومة",32000,"جدة",2016,"صدمة أمامية","المعاينة متاحة.",None),
            ("هايلوكس 2015 للتشليح","تشليح",18500,"الرياض",2015,"أضرار متفرقة","مناسبة للتشليح وقطع الغيار.",None)
        ]
        c.executemany("""INSERT INTO ads(title,category,price,city,year,damage,description,image,user_id)
                         VALUES(?,?,?,?,?,?,?,?,?)""",
                      [(a,b,c,d,e,f,g,h,uid) for a,b,c,d,e,f,g,h in samples])
    c.commit(); c.close()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def home():
    q = request.args.get("q","").strip()
    category = request.args.get("category","").strip()
    c = db()
    ads = c.execute("""SELECT * FROM ads WHERE
        (?='' OR title LIKE ? OR description LIKE ?) AND
        (?='' OR category=?) ORDER BY id DESC""",
        (q,f"%{q}%",f"%{q}%",category,category)).fetchall()
    c.close()
    return render_template("index.html", ads=ads, q=q, category=category)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name,email,password = request.form["name"],request.form["email"],request.form["password"]
        try:
            c=db(); cur=c.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",(name,email,password))
            c.commit(); session["user_id"]=cur.lastrowid; session["user_name"]=name; c.close()
            return redirect(url_for("dashboard"))
        except sqlite3.IntegrityError:
            flash("البريد مستخدم مسبقًا.")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        c=db(); u=c.execute("SELECT * FROM users WHERE email=? AND password=?",
                            (request.form["email"],request.form["password"])).fetchone(); c.close()
        if u:
            session["user_id"]=u["id"]; session["user_name"]=u["name"]
            return redirect(url_for("dashboard"))
        flash("بيانات الدخول غير صحيحة.")
    return render_template("auth.html", mode="login")

@app.get("/logout")
def logout():
    session.clear(); return redirect(url_for("home"))

@app.route("/add", methods=["GET","POST"])
@login_required
def add():
    if request.method=="POST":
        f=request.files.get("image"); filename=None
        if f and f.filename:
            filename=secure_filename(f.filename)
            f.save(os.path.join(UPLOAD, filename))
        c=db()
        c.execute("""INSERT INTO ads(user_id,title,category,price,city,year,damage,description,image)
                     VALUES(?,?,?,?,?,?,?,?,?)""",
                  (session["user_id"],request.form["title"],request.form["category"],
                   int(request.form["price"]),request.form["city"],request.form.get("year"),
                   request.form.get("damage"),request.form.get("description"),filename))
        c.commit(); c.close()
        return redirect(url_for("dashboard"))
    return render_template("add.html")

@app.get("/dashboard")
@login_required
def dashboard():
    c=db(); ads=c.execute("SELECT * FROM ads WHERE user_id=? ORDER BY id DESC",(session["user_id"],)).fetchall()
    c.close(); return render_template("dashboard.html",ads=ads)

@app.get("/ad/<int:ad_id>")
def ad(ad_id):
    c=db(); item=c.execute("""SELECT ads.*,users.name seller FROM ads JOIN users ON users.id=ads.user_id WHERE ads.id=?""",(ad_id,)).fetchone(); c.close()
    if not item: return "الإعلان غير موجود",404
    return render_template("ad.html",ad=item)

@app.post("/delete/<int:ad_id>")
@login_required
def delete(ad_id):
    c=db(); c.execute("DELETE FROM ads WHERE id=? AND user_id=?",(ad_id,session["user_id"])); c.commit(); c.close()
    return redirect(url_for("dashboard"))

if __name__=="__main__":
    init_db()
    app.run(debug=True)
